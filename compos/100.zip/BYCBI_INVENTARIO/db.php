<?php
// db.php

// Cargar la conexión a la base de datos de WordPress
global $wpdb;

// No se declara ninguna función aquí, solo se establece la conexión a la base de datos
?>
